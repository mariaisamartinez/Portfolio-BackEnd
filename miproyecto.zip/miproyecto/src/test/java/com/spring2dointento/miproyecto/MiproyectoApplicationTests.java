package com.spring2dointento.miproyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiproyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
